package com.truco.anotador20;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.content.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  Screen view;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(22,11,7));getWindow().setNavigationBarColor(Color.rgb(22,11,7));view=new Screen(this);setContentView(view);}
  @Override public void onBackPressed(){if(view.mode==1){view.mode=0;view.invalidate();}else super.onBackPressed();}

  class Card {String suit;int n;String special;Card(String s,int n){suit=s;this.n=n;}Card(String x){special=x;}
    String label(){if(special!=null)return special;return n+" de "+suit;}
  }
  class Screen extends View {
    Paint p=new Paint(3); Random rnd=new Random(); int mode=0; // 0 menu,1 game
    ArrayList<Card> deck=new ArrayList<>(),me=new ArrayList<>(),bot=new ArrayList<>();
    Card playedMe,playedBot; int myTricks=0,botTricks=0; int matchMe=0,matchBot=0; int handValue=1; String pending=""; boolean myTurn=true; boolean finished=false; String message="Elegí una carta";
    String[] suits={"espada","basto","copa","oro","bala"};
    int gold=Color.rgb(190,157,78), cream=Color.rgb(245,231,205);
    Screen(Context c){super(c);p.setTypeface(Typeface.create("sans",0));setFocusable(true);}
    float dp(float x){return x*getResources().getDisplayMetrics().density;}
    void wood(Canvas c){float w=getWidth(),h=getHeight();c.drawColor(Color.rgb(37,20,14));int plank=(int)dp(65);for(int x=0;x<w;x+=plank){p.setColor((x/plank%2==0)?Color.rgb(48,27,18):Color.rgb(38,21,15));c.drawRect(x,0,x+plank,h,p);}}
    void text(Canvas c,String s,float x,float y,float size,int col,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(dp(size));p.setTextAlign(a);c.drawText(s,x,y,p);}
    void rr(Canvas c,float l,float t,float r,float b,float rad,int fill,int stroke){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(l,t,r,b),dp(rad),dp(rad),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(stroke);c.drawRoundRect(new RectF(l,t,r,b),dp(rad),dp(rad),p);p.setStyle(Paint.Style.FILL);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);wood(c); if(mode==0)menu(c);else if(mode==1)game(c);else score(c);}
    void menu(Canvas c){float w=getWidth(),h=getHeight();text(c,"TRUCO",w/2,dp(100),40,Color.rgb(243,195,39),Paint.Align.CENTER);text(c,"Tu versión · 5 palos · hasta 40",w/2,dp(137),16,cream,Paint.Align.CENTER);
      rr(c,dp(40),dp(190),w-dp(40),dp(270),18,Color.rgb(26,14,9),gold);text(c,"JUGAR CONTRA LA PC",w/2,dp(240),21,Color.WHITE,Paint.Align.CENTER);
      rr(c,dp(40),dp(300),w-dp(40),dp(380),18,Color.rgb(26,14,9),gold);text(c,"ANOTADOR",w/2,dp(350),21,Color.WHITE,Paint.Align.CENTER);
      text(c,"Truco → Retruco → Vale cuatro → Última",w/2,dp(440),14,Color.rgb(216,189,118),Paint.Align.CENTER);text(c,"Última aceptada = 5 · rechazada = 4",w/2,dp(465),14,Color.rgb(216,189,118),Paint.Align.CENTER);}
    void buildDeck(){deck.clear();for(String s:suits){int[] ns=s.equals("bala")?new int[]{1,2,3,4,5,6,7}:new int[]{1,2,3,4,5,6,7,10,11,12};for(int n:ns)deck.add(new Card(s,n));}deck.add(new Card("Arcángel"));deck.add(new Card("Macho")); // Hembra is 1 basto, not an extra card
      // The new bala cards 1-7 are already represented by the bala suit; Arcángel and Macho are extra specials.
      Collections.shuffle(deck,rnd);}
    int strength(Card x){if(x.special!=null)return x.special.equals("Arcángel")?16:15; if(x.suit.equals("basto")&&x.n==1)return 14; if(x.suit.equals("espada")&&x.n==7)return 13;if(x.suit.equals("bala")&&x.n==7)return 12;if(x.suit.equals("oro")&&x.n==7)return 11;if(x.n==3)return 10;if(x.n==2)return 9;if(x.n==1)return 8;if(x.n==12)return 7;if(x.n==11)return 6;if(x.n==10)return 5;if((x.suit.equals("basto")||x.suit.equals("copa"))&&x.n==7)return 4;if(x.n==6)return 3;if(x.n==5)return 2;return 1;}
    void newHand(){buildDeck();me.clear();bot.clear();for(int i=0;i<3;i++){me.add(deck.remove(deck.size()-1));bot.add(deck.remove(deck.size()-1));}playedMe=playedBot=null;myTricks=botTricks=0;handValue=1;pending="";finished=false;myTurn=true;message="Elegí una carta";}
    void startGame(){matchMe=matchBot=0;newHand();mode=1;invalidate();}
    void score(Canvas c){float w=getWidth(),h=getHeight();text(c,"ANOTADOR",w/2,dp(65),30,Color.rgb(243,195,39),Paint.Align.CENTER);text(c,"Nosotros   "+matchMe+" / 40",w/2,dp(160),22,Color.WHITE,Paint.Align.CENTER);text(c,"Ellos       "+matchBot+" / 40",w/2,dp(215),22,Color.WHITE,Paint.Align.CENTER);rr(c,dp(35),dp(290),w-dp(35),dp(360),16,Color.rgb(26,14,9),gold);text(c,"Volver",w/2,dp(334),20,Color.WHITE,Paint.Align.CENTER);text(c,"20 malas + 20 buenas por lado",w/2,dp(410),15,Color.rgb(216,189,118),Paint.Align.CENTER);}
    void game(Canvas c){float w=getWidth(),h=getHeight();text(c,"TRUCO",w/2,dp(48),29,Color.rgb(243,195,39),Paint.Align.CENTER);text(c,matchMe+"  -  "+matchBot,w/2,dp(82),25,Color.WHITE,Paint.Align.CENTER);text(c,"Vos",w/4,dp(82),15,cream,Paint.Align.CENTER);text(c,"PC",w*3/4,dp(82),15,cream,Paint.Align.CENTER);p.setColor(gold);p.setStrokeWidth(dp(2));c.drawLine(w/2,dp(100),w/2,h-dp(175),p);
      text(c,message,w/2,dp(125),16,cream,Paint.Align.CENTER);text(c,"Cartas jugadas: "+myTricks+" - "+botTricks,w/2,dp(150),13,Color.rgb(216,189,118),Paint.Align.CENTER);
      if(playedMe!=null)drawCard(c,playedMe,w/2-dp(115),dp(175),90,125,false);if(playedBot!=null)drawCard(c,playedBot,w/2+dp(25),dp(175),90,125,false);
      float y=h-dp(150);for(int i=0;i<me.size();i++)drawCard(c,me.get(i),dp(12)+i*dp(102),y,92,130,true);
      if(pending.length()>0){rr(c,dp(25),h-dp(215),w-dp(25),h-dp(165),14,Color.rgb(26,14,9),gold);text(c,pending,w/2,h-dp(182),16,Color.WHITE,Paint.Align.CENTER);}
      rr(c,dp(18),h-dp(62),dp(145),h-dp(18),12,Color.rgb(26,14,9),gold);text(c,"CANTAR",dp(81),h-dp(34),15,Color.WHITE,Paint.Align.CENTER);rr(c,w-dp(145),h-dp(62),w-dp(18),h-dp(18),12,Color.rgb(26,14,9),gold);text(c,"SALIR",w-dp(81),h-dp(34),15,Color.WHITE,Paint.Align.CENTER);
    }
    void drawCard(Canvas c,Card x,float xx,float yy,float ww,float hh,boolean hand){rr(c,xx,yy,xx+dp(ww),yy+dp(hh),10,Color.rgb(245,240,226),Color.rgb(35,25,18));String top=x.special!=null?x.special:(""+x.n);text(c,top,xx+dp(8),yy+dp(23),17,Color.rgb(25,20,15),Paint.Align.LEFT);String su=x.special!=null?"★":x.suit.equals("espada")?"⚔":x.suit.equals("basto")?"♣":x.suit.equals("copa")?"♥":x.suit.equals("oro")?"♦":"•";text(c,su,xx+dp(ww/2),yy+dp(78),31,x.suit!=null&&x.suit.equals("bala")?Color.rgb(35,70,45):Color.rgb(45,35,25),Paint.Align.CENTER);text(c,x.suit==null?"":x.suit,xx+dp(ww/2),yy+dp(106),11,Color.rgb(80,65,45),Paint.Align.CENTER);}
    void play(int idx){if(!myTurn||idx<0||idx>=me.size()||finished)return;playedMe=me.remove(idx);message="La PC está jugando…";invalidate();postDelayed(()->botPlay(),350);}
    void botPlay(){if(bot.isEmpty()){resolveTrick();return;} Card b=bot.remove(rnd.nextInt(bot.size()));playedBot=b;myTurn=false;invalidate();postDelayed(()->resolveTrick(),450);}
    void resolveTrick(){if(playedMe==null||playedBot==null)return;int a=strength(playedMe),b=strength(playedBot);if(a>b){myTricks++;message="Ganaste la baza";}else if(b>a){botTricks++;message="La PC ganó la baza";}else{message="Parda"; if(rnd.nextBoolean())myTricks++;else botTricks++;}playedMe=playedBot=null;if(myTricks>=2||botTricks>=2|| (me.isEmpty()&&bot.isEmpty()))finishHand();else{myTurn=(myTricks>botTricks);invalidate();}}
    void finishHand(){int winner=myTricks>botTricks?0:botTricks>myTricks?1:(rnd.nextBoolean()?0:1);int pts=handValue; if(pending.equals("Última aceptada"))pts=5; if(pending.equals("Última rechazada"))pts=4; if(winner==0)matchMe+=pts;else matchBot+=pts;finished=true;message=(winner==0?"¡Ganaste la mano! +":"La PC ganó la mano. +")+pts+" puntos"; if(matchMe>=40||matchBot>=40){message+=(matchMe>=40?" ¡Partida ganada!":" ¡Partida perdida!");}invalidate();}
    void truco(){if(finished)return; if(handValue==1){pending="Truco";handValue=2;message="Truco: ¿aceptás?";}else if(handValue==2){pending="Retruco";handValue=3;message="Retruco: ¿aceptás?";}else if(handValue==3){pending="Vale cuatro";handValue=4;message="Vale cuatro: ¿aceptás?";}else if(handValue==4){pending="Última";message="Última: ¿aceptás?";}invalidate();}
    void accept(){if(pending.equals("Última")){pending="Última aceptada";handValue=5;message="Última aceptada: se juegan las cartas por 5 puntos";myTurn=true;}else if(!pending.isEmpty()){message=pending+" aceptado";pending="";}invalidate();}
    void reject(){if(pending.equals("Última")){pending="Última rechazada";finished=true;matchMe+=4;message="Última rechazada: +4 puntos para vos";}else if(!pending.isEmpty()){int pts=Math.max(1,handValue-1);matchMe+=pts;finished=true;message="No quiero: +"+pts+" punto(s)";pending="";}invalidate();}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(mode==0){if(y>=dp(190)&&y<=dp(270)){startGame();return true;}if(y>=dp(300)&&y<=dp(380)){mode=2;invalidate();return true;}return true;}if(mode==2){if(y>=dp(290)&&y<=dp(360)){mode=0;invalidate();}return true;}if(x>w-dp(160)&&y>h-dp(75)){mode=0;invalidate();return true;}if(x<dp(160)&&y>h-dp(75)){truco();return true;}if(pending.length()>0&&y>h-dp(215)&&y<h-dp(165)){new AlertDialog.Builder(MainActivity.this).setTitle(pending).setMessage("La PC decide aceptar o rechazar.").setPositiveButton("Aceptar",(d,z)->accept()).setNegativeButton("No quiero",(d,z)->reject()).show();return true;}if(finished){if(y>h-dp(155)){newHand();return true;}return true;}if(y>h-dp(160)){int idx=(int)((x-dp(12))/dp(102));play(idx);return true;}return true;}
  }
}
