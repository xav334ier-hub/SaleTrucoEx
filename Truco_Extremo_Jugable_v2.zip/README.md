# Truco Extremo — proyecto Android

Aplicación nativa Android de anotador de Truco, inspirada en la referencia enviada.

## Características
- 20 puntos de **malas** + 20 puntos de **buenas**.
- Total de 40 puntos por equipo.
- Marcación visual con palitos.
- Botones + y -.
- Nombres editables: Nosotros / Ellos.
- Deshacer.
- Nuevo partido.
- Guarda automáticamente la partida en el teléfono.
- Funciona sin conexión.
- Solo usa APIs nativas de Android; no necesita librerías externas.

## Cómo generar el APK

### Android Studio
1. Instalá Android Studio.
2. Abrí esta carpeta con **File > Open**.
3. Esperá a que termine Gradle Sync.
4. Elegí **Build > Build APK(s)**.
5. La APK de debug quedará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`

### Desde terminal
Con Gradle instalado:
`gradle assembleDebug`

La APK quedará en:
`app/build/outputs/apk/debug/app-debug.apk`

## Requisitos
- Android Studio reciente.
- JDK 17.
- SDK Android 35.
- Gradle 8.9+ si se compila desde terminal.

## Nota
El ZIP contiene el proyecto fuente completo. La APK debe generarse en Android Studio/Gradle; no se incluye una APK precompilada.


## GitHub Actions
Este repositorio incluye `.github/workflows/build-apk.yml`, que compila automáticamente `app-debug.apk` al hacer push a `main` y la publica como Artifact.
