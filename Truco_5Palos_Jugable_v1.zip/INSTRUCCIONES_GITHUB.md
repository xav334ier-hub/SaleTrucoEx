# Anotador Truco 20 — GitHub

Este proyecto está preparado para que GitHub Actions genere la APK automáticamente.

## Desde un celular Android

### 1. Crear el repositorio
1. Entrá a https://github.com/
2. Iniciá sesión.
3. Tocá **+** → **New repository**.
4. Nombre sugerido: `AnotadorTruco20`.
5. Elegí **Public** o **Private**.
6. Tocá **Create repository**.

### 2. Subir el proyecto
IMPORTANTE: no subas solamente el ZIP.

1. Abrí el repositorio recién creado.
2. Tocá **Add file** → **Upload files**.
3. Descomprimí este ZIP en el teléfono.
4. Seleccioná TODOS los archivos y carpetas que están dentro de `AnotadorTruco20_GitHub`.
5. Asegurate de que también se suba la carpeta:
   `.github/workflows/build-apk.yml`
6. Tocá **Commit changes**.

### 3. Esperar a que GitHub compile
Al subir el proyecto, GitHub Actions debería empezar automáticamente.

1. En el repositorio, entrá a **Actions**.
2. Abrí el workflow **Generar APK**.
3. Esperá a que termine con un ✓ verde.

### 4. Descargar la APK
1. Abrí la ejecución terminada.
2. Bajá hasta **Artifacts**.
3. Tocá **AnotadorTruco20-APK**.
4. Se descargará un ZIP que contiene `app-debug.apk`.
5. Descomprimilo y abrí la APK para instalarla.

## Si Actions no se ejecutó
En **Actions → Generar APK → Run workflow** podés iniciarlo manualmente.

## Si Android pregunta por seguridad
Para instalar una APK descargada desde GitHub, Android puede pedir permiso para instalar aplicaciones desde esa fuente. Solo habilitalo si confiás en el archivo que compilaste.

## Qué contiene la app
- 20 malas + 20 buenas = 40 puntos.
- Palitos estilo anotador.
- + y -.
- Nombres editables.
- Deshacer.
- Nuevo partido.
- Guardado local del marcador.
- Funciona sin conexión.

## Nota
Esta es una APK de **debug**, ideal para uso personal y pruebas. No es una versión firmada para publicar en Google Play.
